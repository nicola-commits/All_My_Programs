import discord
import random

token = "OTc2NTgyNzc4NTk2NTA3Njc5.Gx_zcY.5HUb9bSpdimwG9X8g9U9ZltJFexs9XWJ9eP6XQ"

client = discord.Client()

def greeting():
    return random.choice([
        "Hello!",
        "Howdy!",
        "Hi!",
        "Hola!",
        "Ciao!",
        "Hey!"
    ])

@client.event
async def on_ready():
    print(f"bot logged in as {client.user}")

@client.event
async def on_message(msg):
    if msg.author == client.user:
        return
    if msg.content.startswith("!hi"):
        await msg.channel.send(random.choice(["Hello!","Howdy!","Hi!","Hola!","Ciao!","Hey!"]))

client.run(token)