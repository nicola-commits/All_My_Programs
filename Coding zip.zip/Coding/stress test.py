import multiprocessing

def useful():
    while True:print("Hi")

for _ in range(10):
    p1 = multiprocessing.Process(target=useful())
    p1.start()