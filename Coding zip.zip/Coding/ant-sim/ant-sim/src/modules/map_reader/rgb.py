from PIL import Image
import json
import numpy as np

def create_img(inp="screenshot.json", output="screenshot.jpg"):
    with open(inp, 'r') as file:
        data = json.loads(file.read())
        imgcolors = data["pixels"]
        food_coordinates = data["food_coordinates"]
    pixelsthrow = imgcolors
    pixelsthrow[food_coordinates[0]][food_coordinates[1]] = (0, 255, 0)

    Image.fromarray(np.asarray(pixelsthrow), 'RGB').save(output)
    Image.fromarray(np.asarray(np.asarray(item, dtype=np.uint8) for item in pixelsthrow), 'RGB').show()

if __name__ == "__main__":
    create_img()