#include <stdio.h>

int main(){

    int num1;
    int num2;
    printf("Enter the first number please: ");
    scanf("%d", &num1);
    printf("Enter the second number: ");
    scanf("%d",  &num2);
    printf("Sum of the two numbers is %d \n", num1+num2);
}