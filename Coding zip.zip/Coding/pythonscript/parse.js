const nearley = require('nearley');
const grammar = require('./grammar.js');
const fs = require("mz/fs");

const parser = new nearley.Parser(nearley.Grammar.fromCompiled(grammar));

async function main(){
    const filename = process.argv[2];
    if(!filename){
        console.log("Please provide a .small file");
        return;
    }

    const code = (await fs.readFile(filename)).toString();
    const parser = new nearley.Parser(nearley.Grammar.fromCompiled(grammar));
    const outputfilename = filename.replace(".ps", ".ast");

    parser.feed(code);

    if (parser.results.length > 1){
        console.log("ERROR: AMBIGOUS GRAMMAR DETECTED")
    }
    else{
        const ast = parser.results;
        await fs.writeFile(outputfilename, JSON.stringify(ast, null, "  "));
        console.log(`Wrote to ${outputfilename}.`);
    }

}

main().catch(err => console.log(err.stack));