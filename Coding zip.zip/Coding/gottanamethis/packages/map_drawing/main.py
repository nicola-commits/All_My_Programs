#module to create a map drawing.
#global variables
eraser_size = 50
pencil_size = 20
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
drawn = []

#pixel class
class Pixel:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __repr__(self):
        return f"self.x = {self.x}; self.y = {self.y}"

#import modules
from time import sleep
import pygame as pg

#draw a screen
screen = pg.display.set_mode((400, 400))

def check(l:list, x:int, y:int):
    for item in l:
        if item.x == x and item.y == y:
            return True
    return False

#main event loop
while True:
    #event listener
    for event in pg.event.get():
        if event.type == pg.QUIT:
            quit()
        else:
            #(left, scroll click, right)
            mousestate = pg.mouse.get_pressed()
            #if buttons are not being pressed, ignore
            if not any(mousestate):
                continue
            #get the coordinates
            coord = pg.mouse.get_pos()
            #if left click, place pixels
            if mousestate[0]:
                #create the pixels
                for x in range(
                    int(-pencil_size/2), 
                    int(pencil_size/2)
                    ):
                    for y in range(
                        int(-pencil_size/2), 
                        int(pencil_size/2)
                        ):
                        if not check(
                            drawn, 
                            coord[0]+x, 
                            coord[1]+y
                        ):
                            drawn.append(
                                Pixel(
                                    coord[0] + x, 
                                    coord[1] + y
                                )
                            )
            #else if right click, delete pixels
            elif mousestate[2]:
                for p in drawn:
                    if coord[0] - eraser_size/2 < p.x < coord[0] + eraser_size/2 and coord[1] - eraser_size/2 < p.y < coord[1] + eraser_size/2:
                        drawn.remove(p)
    #fill with black
    screen.fill(BLACK)
    #now fill the pixels that have been drawn
    for p in drawn:
        pg.draw.circle(screen, (255, 255, 255), (p.x, p.y), 5)