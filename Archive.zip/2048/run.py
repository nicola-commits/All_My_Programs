import pygame
import random

def makegrid(w, h, curres, SCREEN):
    for i in range(0, curres[0], w):
        for _ in range(0, curres[1], h):
            pygame.draw()


pygame.init()
SCREEN = pygame.display.set_mode((600, 600))
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            break
    SCREEN.fill((0, 0, 0))
    pygame.display.update()