import pygame
import helper

size = 5

grid = [list(range(size)) for _ in range(size)]

class redstone():
    def __init__(self, x, y):
        grid[x][y] = self
        self.x = x
        self.y = y
        self.up = self.down = self.left = self.right = False
        self.activated = False

    def __str__(self):
        return f"Object redstone at {hex(id(self))}. Properties: self.x = {self.x}, self.y = {self.y}, self.up = {self.up}, self.down = {self.down}, self.right = {self.right}, self.left = {self.left}, activated? {self.activated}"
    
    def __repr__(self):
        return "r"

    def update(self):
        for x, y in helper.near_coords(self.x, self.y):
            try:
                if isinstance(grid[x][y], redstone):
                    try:
                        print(helper.updownrightleft((self.y, self.x), (y, x)))
                        {'right': self.right, 'left': self.left, 'up': self.up, 'down': self.down}[helper.updownrightleft((self.y, self.x), (y, x))] = True
                    except SyntaxError:
                        pass
            except IndexError:
                continue



screen = pygame.display.set_mode((500, 500))

a = redstone(4, 3)
grid[4][2] = a
a.update()
print(grid)
print(a)

while True:

    screen.fill((255, 255, 255))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()

    pygame.display.update()