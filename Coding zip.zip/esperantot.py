import bs4
import requests
from tkinter import *
#-------INITIALIZE VARIABLES-------
wordsdict = {}

#-------Screen class-------
class screen():
    def __init__(self, sc:Tk):
        self.root = sc

#-------Functions-------
def getres():
    """
    Web scrape for the result
    """
    if l.get() in wordsdict.keys():
        resultl.configure(text=wordsdict[l.get()])
        return #guard clause for better readability
    #-------actual web scraping-------
    #take input from user and replace spaces with + for url
    req = l.get().replace(' ', '+')
    #load the page using requests
    page = requests.get(f"https://www.google.com/search?channel=fs&client=ubuntu&q=translate+{req}+in+esperanto")
    #load the soup and find the div with the translation on it
    resultl.configure(text=bs4.BeautifulSoup(page.content, features="html.parser").find_all('div', id="lrtl-translation-text")[-1].get_text())
    if len(l.get().split(' ')) == 1: #if it's a word
        with open(r"words.txt", 'a') as infile: #write the translation and the word into the file
            infile.write(l.get()+','+bs4.BeautifulSoup(page.content, features="html.parser").find_all('div', id="lrtl-translation-text")[-1].get_text()+'\n')
    loaddata()

def loaddata():
    """
    Loads the data into the dictionary
    """
    with open(r"words.txt", 'r') as infile:
        for item in infile.readlines():
            wordsdict[item.split(',')[0]] = item.split(',')[1].strip('\n')

#-------Load the data-------
loaddata()


#-------tkinter stuff-------
root = screen(Tk())
l = Entry(root.root, text='What do you want to translate?')
b = Button(root.root, text='Translate!', command=getres)
resultl = Label(root.root)
l.pack()
b.pack()
resultl.pack()
#mainloop of the root
root.root.mainloop()