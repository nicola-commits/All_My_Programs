def binary_search(l, target:int):
    iterations = 0
    while True:
        little, big = l[:int(len(l)/2)], l[int(len(l)/2):]
        iterations += 1
        if little == big == target:
            return iterations
        if little == big:
            raise Exception
        l = big if little[-1] < target else little

print(binary_search([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 ,14, 15, 16, 17, 18, 19], 13))
    