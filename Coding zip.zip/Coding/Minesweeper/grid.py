from main import grid_size

class bomb():
    """
    Class for a bomb. Doesn't actually do anything
    """
    def __init__(self) -> None:
        self.discovered = False
    def __str__(self) -> str:
        return 'b'

class number():
    """
    Class for numbers. Holds self.value
    """

    def __init__(self, value:int) -> None:
        self.value = value
        self.discovered = False

    def __str__(self) -> str:
        return str(self.value)

class grid():
    """
    Class for the grid.
    self.size is the size of the grid a sizexsize grid.
    self.bombs is the size of how many bombs will the grid have
    self.grid is a bidimensional array which contains all the blocks
    """
    def __init__(self, size:int) -> None:
        self.size = size
        self.bombs = int(size * 1.2)
        self.grid = [[number(0) for _ in range(size)] for _ in range(size)]

    def __str__(self) -> str:
        return self.transform()

    def calculatenearbombs(self, x:int, y:int) -> int:
        """
        Calculates how many bombs are near the specified cell and returns it
        """

        #-------Initialize values-------
        res = 0
        dylist = [-1, 0, 1] if y != 0 else [0, 1]
        dxlist = [-1, 0, 1] if x != 0 else [0, 1]
        #No need to check for x > grid_size because it will be handled by the exception

        #-------check all the ones
        for dy in dylist:
            for dx in dxlist:
                try:
                    if (dy != dx or dy != 0) and isinstance(self.grid[x+dx][y+dy], bomb):
                        res+=1
                except IndexError:
                    pass
        return res

    def transform(self):
        """
        Used for __str__(), makes the grid human-readable
        """
        res = '[\n'

        for item in self.grid:
            res += '['

            for i in item:
                res += str(i)
                
            res += ']'
            res += '\n'

        res += ']'
        return res

    def createrandom(self) -> None:
        """
        Creates a random bomb at a random location (excluding (0, 0))
        """
        import random

        x, y = random.randrange(0, self.size), random.randrange(0, self.size)

        if (x, y) == (0,  0) or isinstance(self.grid[x][y], bomb): #if 0 0 or if the item is a bomb then repeat until it's not a bomb
            self.createrandom()
            return

        self.grid[x][y] = bomb()

    def creategrid(self):
        """
        Creates the grid. Uses createrandom multiple times, then gives every non-bomb square a number depending on the quantity of bombs near itself
        """

        #-------Create the bombs-------
        for _ in range(self.bombs):
            self.createrandom()

        #-------Give a number to every non-bomb square-------
        for i, elem in enumerate(self.grid):
            for j, item in enumerate(elem):
                #-------Only give it if it's NOT a bomb-------
                if not isinstance(item, bomb):
                    self.grid[i][j] = number(self.calculatenearbombs(i, j))

    def updategrid(self) -> None:
        """
        Updates the grid by assigning the number every square should have
        """

        #-------Give a number to every non-bomb square-------
        for i, elem in enumerate(self.grid):

            for j, item in enumerate(elem):

                #-------Only give it if it's NOT a bomb-------
                if not isinstance(item, bomb):
                    self.grid[i][j] = number(self.calculatenearbombs(i, j))


    def uncover(self, x:int, y:int) -> None:
        """
        Uncovers the piece at x, y.
        If the piece is a number, uncover it. If it's a bomb, end the game.
        If it's a number 0, uncover everything near it and do the same if one of those is a 0.
        """

        #-------Uncover the piece-------
        self.grid[x][y].uncover = True

        #-------If it's a bomb then finish the game-------
        if isinstance(self.grid[x][y], bomb):
            end = True
            return
        
        #-------If it's a 0, uncover all the ones near it-------
        if self.grid[x][y].value == 0:
            dylist = [-1, 0, 1] if y != 0 else [0, 1]
            dxlist = [-1, 0, 1] if x != 0 else [0, 1]
            #No need to check for x > grid_size because it will be handled by the exception

            for dy in dylist:
                for dx in dxlist:
                    try:

                        if (dy != dx or dy != 0):
                            self.grid[x+dx][y+dy].discovered = True
                            
                            if self.grid[x+dx][y+dy].value == 0:
                                self.uncover(self.grid[x+dx][y+dy])
                        
                    except IndexError:
                        pass