class Solution:
    def twoSum(self, nums: list[int], target: int) -> list[int]:
        seen = {}
        for i, item in enumerate(nums):
            if (target- item) in seen.keys():
                return [i, seen[target-item]]
            seen[item] = i

print(Solution().twoSum([1, 2, 3, 4, 5, 6, 8, 9], 8))