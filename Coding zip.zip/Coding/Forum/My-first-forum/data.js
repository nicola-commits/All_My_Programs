var threads = [
    {
        id:1,
        title: "META Thread",
        author: 'Nicola',
        date : 1640853025000,
        comments : [
            {
                author : 'AutoMod',
                date : 1640854000000,
                content : "Please check that your submission respects the site's rules before posting"
            },
            {
            author : 'commentauth1',
            date : 1640854000000,
            content : 'very interesting thoughts!'
            }
        ]
    },
    {
        id:2,
        title: "Thread 2",
        author: 'Ronan',
        date : 1640854165000,
        comments : []
    }
]

var def = {
    'Ilaria':'3141',
    'Ronan':'Iliketrains',
    'Nicola':'1234'
}

userpw = JSON.parse(localStorage.getItem('userpw'))
if(userpw == null){
    userpw = def;
}

var threads;
if(localStorage && localStorage.getItem('threads')) {
    threads = JSON.parse(localStorage.getItem('threads'));
} else {
    threads = defaultThreads;
    localStorage.setItem('threads', JSON.stringify(dafaultThreads))
}