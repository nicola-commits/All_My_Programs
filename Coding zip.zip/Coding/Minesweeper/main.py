from grid import grid, bomb, number
import pygame

#-------GLOBAL VARS-------
grid_size = 24
screen_height = 1024
screen_width = 1280

#-------DISPLAY-------
screen = pygame.display.set_mode((screen_width, screen_height))

#-------GRID-------
g = grid(15)
g.creategrid()

#-------GLOBAL FUNCTIONS-------
def drawat(x:int, y:int) -> None:
    """
    draws the square at the coordinates x and y\nargs:
    x:int
    y:int
    returns: None
    """
    square = g[x][y]
    if not square.discovered: #if the square is not yet discovered (clicked on):
        #-------DON'T DO ANYTHING-------
        return
    if isinstance(square, bomb):
        #-------PUT THE IMAGE OF A BOMB-------
        #TODO
        return
    if isinstance(square, number):
        #-------PUT THE NUMBER-------
        #TODO
        return

def drawgrid() -> None:
    for i in range(grid_size+1):
        top = (i*screen_width/grid_size, 0)
        bottom = (i*screen_width/grid_size, screen_width)
        pygame.draw.line(screen, (0, 0, 0), top, bottom)
    for i in range(grid_size+1):
        top = (0, i*screen_width/grid_size)
        bottom = (screen_width, i*screen_width/grid_size)
        pygame.draw.line(screen, (0, 0, 0), top, bottom)


#-------MAIN LOOP-------
while True:

    #-------BG COLOR-------
    screen.fill((230, 230, 230))
    drawgrid()

    #-------EVENT HANDLER-------
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()

    #-------UPDATE DISPLAY-------
    pygame.display.update()