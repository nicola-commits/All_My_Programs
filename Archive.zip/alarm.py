import multiprocessing
import time
def createandsoundalarm(t):
    def soundalarm(t):    
        time.sleep(t)
        print('Alarm')
    multiprocessing.Process(target=soundalarm, args=(t,)).start()

from tkinter import *
root = Tk()
entry = Entry(root)
entry.pack()
button = Button(root, command=lambda:createandsoundalarm(entry.get()))
root.mainloop()