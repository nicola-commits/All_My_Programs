# Ant-sim
 Second attempt for an ant simulation. This time, it's going to be much better
