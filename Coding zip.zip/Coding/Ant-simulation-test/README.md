# Ant-simulation-test
"Ant simulation" built on Python with Pygame.

The only package needed is Pygame, you can install it with
`pip install pygame` or using requirements.txt by
`cd src`
`pip install -r requirements.txt`
