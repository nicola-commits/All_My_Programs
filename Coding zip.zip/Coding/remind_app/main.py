from tkinter import *

class screen():
    def __init__(self, root):
        self.root = root
    def update(self):
        self.root.mainloop()

class remind():

    def __init__(self, name, repeat=None):
        self.name = name
        self.repeat = repeat

    def __repr__(self):
        return f"self.name : {self.name}, self.repeat: {self.repeat}"

#-------SCREEN-------
#root
root = screen(Tk())
#remindername
remname = Entry(root.root)
remname.pack()

root.update()
    