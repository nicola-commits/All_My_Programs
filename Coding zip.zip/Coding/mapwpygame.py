import pygame

screen = pygame.display.set_mode((400, 500))

while True:
    screen.fill((0,0,0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()


    pygame.display.update()