"""
Useful python function for most things.
"""

from typing import Iterable
import time
import random

def test(func):
    def wrapper(*args, **kwargs):
        now = time.time()
        print(func(*args, **kwargs))
        for _ in range(99999):
            func(*args, **kwargs)
        print(f"Time employed: {time.time()-now}")
    return wrapper
        


def divide_equal(start:int, end:int, num:int) -> list:
    if start == end or num == 1:
        return [start, end]
    res = [start]
    for _ in range(num):
        res.append(res[-1] + (end-start)/num)
    return res

def near_coords(x:int, y:int) -> Iterable:
    dxl = [0, 1] if x == 0 else [-1, 0, 1]
    dyl = [0, 1] if y == 0 else [-1, 0, 1]
    for dx in dxl:
        for dy in dyl:
            if dx == 0 and dx == y:
                continue
            yield (x+dx, y+dy)

def calc_m(start_coords:list[int, int], end_coords:list[int, int]) -> int:
    """
    Calculates the coefficient that leads from the start to the end\nArgs:
    start_coords: list[int, int]/tuple(int, int) (x, y)
    end_coords: list[int, int]/tuple(int, int) (x, y)
    Returns:
    int
    """
    #The slope of a line is dy/dx
    dy = start_coords[1] - end_coords[1]
    dx = start_coords[0] - end_coords[0]
    if dx == 0:
        return 0
    return dy/dx

def updownrightleft(start:list[int, int], end:list[int, int], invert:bool=False) -> str:
    """
    Returns if the end coordinate is up, right, left or right respect to the start ones.\nArgs;
    start: list[int, int]
    end: list[int, int]
    invert:bool (default False)
    """

    if invert:
        up = 'down'
        down = 'up'
        left = 'right'
        right = 'left'
    
    else:
        up = 'up'
        down = 'down'
        left = 'left'
        right = 'right'
    
    if start[0] > end[0]:
        return left

    if start[0] < end[0]:
        return right
    
    if start[1] > end[1]:
        return down
    
    if start[1] < end[1]:
        return up
    
    raise SyntaxError

def twosum(l:list[int], target:int)->tuple:
    d = {}
    for i in range(len(l)):
        if target - d[i] == l[i]:
            return

@test
def fib(n):
    f = {0:0, 1:1}
    for i in range(2, n+1):
        f[i] = f[i-1] + f[i-1]
    return f[n]

fib(872)
